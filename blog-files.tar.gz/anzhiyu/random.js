var posts=["posts/4a17b156/","posts/0/","posts/5f4c36ca/","posts/c179dee7/","posts/661cd695/","posts/b9fb84c9/"];function toRandomPost(){
    pjax.loadUrl('/'+posts[Math.floor(Math.random() * posts.length)]);
  };